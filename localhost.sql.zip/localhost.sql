-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 09, 2017 at 08:16 AM
-- Server version: 10.1.20-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `books`
--
CREATE DATABASE IF NOT EXISTS `books` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `books`;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `author_id` int(11) NOT NULL,
  `author_name` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`author_id`, `author_name`) VALUES
(1, 'Здравка Паскалева'),
(2, 'Георги Паскалев'),
(3, 'Мая Алашка'),
(4, 'Станислава Петкова'),
(5, 'Юлия Нинова'),
(6, 'Снежинка Матакиева'),
(7, 'Таня Тонова'),
(8, 'Чавдар Лозанов'),
(9, 'Теодоси Витанов'),
(10, 'Анна Калчева'),
(11, 'Румяна Караджова'),
(12, 'Георги Ганчев'),
(13, 'Николай Райков'),
(14, 'Веселина Дамянова'),
(15, 'Иван Георгиев'),
(16, 'Петър Недевски'),
(20, 'Запрян Запрянов'),
(19, 'Петьо Петков'),
(21, 'Васил Гюзелев');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int(11) NOT NULL,
  `book_title` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `book_title`) VALUES
(1, 'Математика за 6 клас Архимед'),
(2, 'Математика за 6 клас Просвета'),
(3, 'Математика за 6 клас Анубис'),
(4, 'Математика за 7 клас Архимед'),
(5, 'Математика за 7 клас Просвета'),
(6, 'Математика за 7 клас Анубис'),
(7, 'Математика за 8 клас Архимед'),
(8, 'Математика за 8 клас Просвета'),
(9, 'Математика за 8 клас Анубис'),
(17, 'Математиза за 10 клас Просвета');

-- --------------------------------------------------------

--
-- Table structure for table `books_authors`
--

CREATE TABLE `books_authors` (
  `book_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books_authors`
--

INSERT INTO `books_authors` (`book_id`, `author_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(2, 4),
(2, 5),
(2, 6),
(2, 7),
(3, 8),
(3, 9),
(3, 10),
(4, 1),
(4, 2),
(4, 3),
(5, 4),
(5, 5),
(5, 6),
(6, 8),
(6, 9),
(6, 10),
(6, 11),
(7, 1),
(7, 2),
(7, 3),
(8, 4),
(8, 12),
(8, 13),
(8, 14),
(8, 15),
(9, 8),
(9, 9),
(9, 16),
(17, 15),
(17, 19),
(20, 21),
(20, 22),
(20, 23),
(21, 21),
(21, 22),
(21, 23),
(22, 22),
(22, 23),
(23, 22),
(23, 23),
(24, 20),
(24, 19),
(24, 21),
(25, 20),
(25, 19),
(25, 21);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `message_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `message_date` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`message_id`, `message`, `message_date`, `user_id`, `book_id`) VALUES
(28, 'hoih', '2017-02-08 13:33:36', 1, 9),
(2, 'тест коментар 3', '2017-01-13 18:17:58', 1, 17),
(3, 'тест 4', '2017-01-13 18:18:43', 2, 17),
(4, 'тест 5', '2017-01-13 18:19:23', 2, 7),
(5, 'Този учебник е много зле. Моите ученици няма да го ползват за нищо на света :(', '2017-02-07 11:43:53', 1, 5),
(25, 'sdgsgs', '2017-02-07 18:03:04', 1, 8),
(30, 'aaaa', '2017-02-08 13:39:51', 1, 5),
(29, 'sfafafg', '2017-02-08 13:38:32', 1, 5),
(22, 'egweywrywyw', '2017-02-07 18:01:04', 1, 8),
(23, 'egweywrywyw', '2017-02-07 18:02:02', 1, 8),
(24, 'egweywrywyw', '2017-02-07 18:02:28', 1, 8),
(14, 'ok', '2017-02-07 14:00:17', 1, 5),
(26, 'dgsdgs', '2017-02-07 18:05:16', 1, 8),
(27, 'fsdfaf', '2017-02-07 18:05:32', 1, 8),
(31, 'aaaa', '2017-02-08 13:57:50', 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`) VALUES
(1, 'denninnka', 'qwerty'),
(2, 'user', 'qwerty'),
(3, 'Соня', 'qwerty');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`author_id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `books_authors`
--
ALTER TABLE `books_authors`
  ADD KEY `book_id` (`book_id`),
  ADD KEY `author_id` (`author_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `author_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
